// Copy this file to src/script/seed/seed.data.ts
import { UserRole } from "src/role/role.model";
import { SeedData } from "./seed.model";

export const seedData: SeedData = {
  users: [
    {
      email: "superadmin@mail.com",
      password: "superadmin123",
      mobileNumber: "+15551234567",
      name: "Super Admin",
      username: "superadminuser",
      hometown: "Springfield",
      role: UserRole.SUPER_ADMIN,
    },
    {
      email: "admin@mail.com",
      password: "admin123",
      mobileNumber: "+15551234568",
      name: "Admin User",
      username: "adminuser",
      hometown: "Springfield",
      role: UserRole.ADMIN,
    },
    {
      email: "user@mail.com",
      password: "user123",
      mobileNumber: "+15551234569",
      name: "Default User",
      username: "defaultuser",
      hometown: "Springfield",
      role: UserRole.USER,
    },
  ],
};
