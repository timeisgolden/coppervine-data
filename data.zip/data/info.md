## Notes
- Contact me if you have any questions.
  - Gmail: `silverbullet8868@gmail.com`
  - Skype: search with `silverbullet8868`. the skype name is `live:silverbullet8868` 
-  For accounts 2FA enabled, ask me the verification code when you login, then update with yours. 

## Accounts
### Emails
- `baifeng1991321@gmail.com`
  - Pwd: `dbLiFYGyCq17DzG0`
  - This is the recovery email for all other emails.
  - 2FA enabled.

- `bai@coppervine.io`
  - Pwd: `dbLiFYGyCq17DzG0`

- `kris@coppervine.io`
  - Pwd: `dbLiFYGyCq17DzG0`

- `baifeng1991321@outlook.com`
  - Pwd: `dbLiFYGyCq17DzG0`

- `devmanateam@outlook.com`
  - Pwd: `dbLiFYGyCq17DzG0`

### Github
- `kris@coppervine.io`
  - Username: `coppervinedev`
  - Pwd: `dbLiFYGyCq17DzG0`
- `baifeng1991321@gmail.com`
  - Pwd: `dbLiFYGyCq17DzG0`
  - Username: `timeisgolden`
  - 2FA enabled

### Slack
- `kris@coppervine.io`
- `bai@coppervine.io`

### AWS Console
- CopperVine environment
  - Access Portal URL: https://d-9067d65985.awsapps.com/start/
  - Username: `BaiFeng`
  - Password: `Qu/QI2Czd520lBW8`
  - 2FA enabled
- Client's environment
  - Account ID: `640168453014`
  - IAM username: `rakia@coppervine.io`
  - Pwd: `i6T1sUoQcJfxywmM`

### GoDaddy
- Username: `kris@coppervine.io`
- Pwd: `Qu/QI2Czd520lBW8`
- `Account Settings / Delegate Access / Alan Prewitt / thegetawayclubapp.com`

### Twilio (CopperVine)
- `ea@coppervinestudio.com`
- Pwd: `myx2zaeNDTafbqpa`
- 2FA enabled

### Figma
- `kris.coppervine.io`
  - GAuth
- `bai.coppervine.io`
  - GAuth

## Github repositories
- Mobile App: https://github.com/Copper-Vine-Studio/thegetawayclub-app
  - Login with `baifeng1991321@gmail.com` account
- Backend: https://github.com/coppervinedev/thegetawayclub-api
  - Login with `kris@coppervine.io` account
- Landing Page: https://github.com/coppervinedev/thegetawayclub-landing
  - Login with `kris@coppervine.io` account

## Resources
- https://drive.google.com/drive/folders/16fx44H54fc8iikRWTC9046YOkRHVpudf
- https://www.figma.com/design/Ti9FQha8mMANVFXjW95V9J/Final-UI---Copper-%26-Vine-Studio---The-Getaway-App?t=wUBXwhBoqwNlAyiQ-0
- https://www.figma.com/design/rq4eGXfeu0Ge9HehtGlmTf/FC5015052---Copper-%26-Vine-Studio---GETAWAY-CLUB-PRE-LAUNCH-LANDING-PAGE?node-id=0-1&node-type=canvas&t=cTGMITY1Kd4YiE70-0

## Payment
- Ask client to setup new Gusto accounts for both Kris and Bai.